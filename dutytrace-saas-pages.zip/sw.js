/**
 * Secure service worker
 * Caches the app shell (this single-page HTML plus its icons/manifest) so the
 * app still opens when the phone/computer has no signal. It does NOT try to
 * cache or intercept Firebase (gstatic.com) or the bills Worker
 * (workers.dev) -- those requests always go straight to the network, and
 * the app's own offline queue (in the page's JS) already handles saving
 * data while offline.
 *
 * v2 change (important): v1 served the app shell CACHE-FIRST — check the
 * cache, and only ever hit the network if nothing was cached yet. That
 * meant once a browser had this installed, EVERY future code update to
 * index.html (dutytrace.html) or guard.html could sit live on
 * dutytrace.pages.dev correctly deployed, and that browser would still
 * keep serving whatever copy it originally cached, forever — no amount of
 * a normal reload or even Ctrl+Shift+R fixes that, because the service
 * worker's fetch handler intercepts the reload's own network request too,
 * and cache-first never lets it through to the network to notice anything
 * changed. Only a byte-different sw.js file makes a browser even check for
 * an update at all — and since sw.js itself was never touched across all
 * the previous fixes, browsers with this already installed had no way to
 * know anything had changed.
 *
 * v2 switches the app shell to NETWORK-FIRST: always try the network (so a
 * new deploy is picked up on the very next load while online), and only
 * fall back to the cached copy if the network request fails (genuinely
 * offline) — which is when this caching exists for in the first place.
 * Bumping CACHE_NAME to v2 is what makes THIS particular update finally
 * get noticed and installed even under the old v1 service worker.
 *
 * v3 adds guard.html + guard-manifest.json to the cached shell so the guard
 * GPS-attendance page is independently installable ("Add to Home Screen")
 * and still opens offline, same as the admin dashboard already did. The
 * offline navigation fallback is now request-aware: a failed navigation to
 * guard.html falls back to the cached guard.html, not the admin dashboard
 * (previously every offline navigation fell back to index.html, which
 * would have shown a guard the wrong app). Bumping CACHE_NAME to v3 makes
 * browsers notice and install this update.
 */

const CACHE_NAME = 'dutytrace-shell-v9';
const SHELL_FILES = [
  './',
  './index.html',
  './manifest.json',
  './guard.html',
  './guard-manifest.json',
  './icon-192.png',
  './icon-512.png',
  './shield.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) => Promise.all(
      names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  // Let Firebase / bills-worker / any other cross-origin traffic pass through untouched.
  if (url.origin !== self.location.origin) return;

  // App-shell files: network-first, falling back to the cached copy only when the
  // network request itself fails (offline) — re-caching every successful response so
  // the offline fallback stays reasonably fresh too.
  event.respondWith(
    fetch(req).then((res) => {
      if (res && res.status === 200) {
        const copy = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
      }
      return res;
    }).catch(() => caches.match(req).then((cached) => {
      if (cached) return cached;
      // Last resort for a navigation whose exact page wasn't cached: send the guard app
      // to the guard shell, everything else to the admin shell, rather than always
      // defaulting to the admin dashboard.
      const isGuardPath = url.pathname.endsWith('/guard.html');
      return caches.match(isGuardPath ? './guard.html' : './index.html');
    }))
  );
});

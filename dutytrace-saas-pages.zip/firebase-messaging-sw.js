// Secure — background push handler.
// Runs even when the Guard Login page / admin dashboard is closed, so login/logout
// reminders and admin alerts still show up as a normal system notification.
// Must live at the site root (same folder as index.html/guard.html) — that's the
// default scope Firebase's getToken() registers against.

importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');

// dutytrace-saas project config (the apiKey here is a public, domain-restricted
// identifier — this is the standard/expected place for it, same as any other
// Firebase web app).
firebase.initializeApp({
  apiKey: "AIzaSyCFnk_xvkOS2wpnA6E7Hc13hkhmLXfVsQU",
  authDomain: "dutytrace-saas.firebaseapp.com",
  databaseURL: "https://dutytrace-saas-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "dutytrace-saas",
  storageBucket: "dutytrace-saas.firebasestorage.app",
  messagingSenderId: "230342626064",
  appId: "1:230342626064:web:db7f420f60d4c2a5587395"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const title = (payload.notification && payload.notification.title) || 'Secure';
  const body = (payload.notification && payload.notification.body) || (payload.data && payload.data.body) || '';
  const url = (payload.data && payload.data.url) || '/';
  self.registration.showNotification(title, {
    body,
    icon: 'icon-192.png',
    badge: 'icon-192.png',
    data: { url }
  });
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) { if (c.url.indexOf(url) !== -1 && 'focus' in c) return c.focus(); }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});
